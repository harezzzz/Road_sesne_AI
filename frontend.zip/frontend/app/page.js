"use client";
import { useState } from "react";

export default function Home() {
    const [file, setFile] = useState(null);
    const [preview, setPreview] = useState(null);
    const [loading, setLoading] = useState(false);
    const [response, setResponse] = useState(null);
    const [error, setError] = useState(null);

    const handleFileChange = (e) => {
        const selected = e.target.files[0];
        setFile(selected);
        setError(null);
        if (selected) {
            setPreview(URL.createObjectURL(selected));
        }
    };

    const handleSubmit = async () => {
        if (!file) {
            setError("Please upload an image first.");
            return;
        }

        setLoading(true);
        setResponse(null);
        setError(null);

        const formData = new FormData();
        formData.append("file", file);

        try {
            const res = await fetch("https://roadsense-backend.onrender.com/analyze", {
                method: "POST",
                body: formData,
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.detail || "Analysis failed");
            }

            const data = await res.json();
            setResponse(data);
        } catch (err) {
            setError(err.message);
        }

        setLoading(false);
    };

    return (
        <div className="min-h-screen bg-gray-100 flex flex-col items-center p-8">
            <h1 className="text-4xl font-bold mb-2">RoadSense AI</h1>
            <p className="text-gray-600 mb-6">
                Upload a road image and get intelligent interpretation of utility markings.
            </p>

            <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-2xl">
                <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="mb-4"
                />

                {preview && (
                    <img
                        src={preview}
                        alt="Preview"
                        className="mb-4 rounded border"
                    />
                )}

                <button
                    onClick={handleSubmit}
                    disabled={loading}
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                    {loading ? "Analyzing..." : "Analyze Image"}
                </button>

                {error && (
                    <p className="mt-4 text-red-600">{error}</p>
                )}
            </div>

            {response && (
                <div className="mt-6 bg-white p-6 rounded-lg shadow-md w-full max-w-2xl">
                    <h2 className="text-xl font-semibold mb-2">AI Analysis</h2>
                    <p><strong>Detected Labels:</strong> {response.detected_labels.join(", ") || "None detected"}</p>
                    <p className="mt-2"><strong>Interpretation:</strong> {response.interpretation}</p>
                    <p className="mt-2"><strong>Safety Notes:</strong> {response.safety_notes}</p>
                    <p className="mt-2"><strong>Confidence:</strong> {response.confidence}</p>
                </div>
            )}
        </div>
    );
}
