import os
import uuid
import logging
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from models import RoadMarkingAnalysis
from ocr import extract_text_from_image
from agent import analyze_road_marking

app = FastAPI(title="RoadSense AI Backend")

logging.basicConfig(level=logging.INFO)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_TYPES = ["image/png", "image/jpeg", "image/jpg"]
MAX_FILE_SIZE_MB = 5

@app.get("/health")
def health_check():
    return {"status": "ok"}

@app.post("/analyze", response_model=RoadMarkingAnalysis)
async def analyze_image(file: UploadFile = File(...)):
    try:
        # ---- Validation ----
        if file.content_type not in ALLOWED_TYPES:
            raise HTTPException(status_code=400, detail="Only PNG/JPG images allowed")

        contents = await file.read()
        if len(contents) > MAX_FILE_SIZE_MB * 1024 * 1024:
            raise HTTPException(status_code=400, detail="File too large (max 5MB)")

        file_id = str(uuid.uuid4()) + "_" + file.filename
        file_path = os.path.join(UPLOAD_DIR, file_id)

        with open(file_path, "wb") as buffer:
            buffer.write(contents)

        logging.info(f"Received image: {file.filename}")

        # ---- OCR ----
        extracted_text = extract_text_from_image(file_path)
        logging.info(f"OCR extracted: {extracted_text}")

        # ---- AI Agent (with basic retry) ----
        for attempt in range(2):
            try:
                result = await analyze_road_marking(extracted_text)
                return result
            except Exception as e:
                logging.error(f"Agent attempt {attempt+1} failed: {str(e)}")
                if attempt == 1:
                    raise e

    except HTTPException as e:
        raise e

    except Exception as e:
        logging.error(f"Server error: {str(e)}")
        return RoadMarkingAnalysis(
            detected_labels=[],
            interpretation="Server encountered an unexpected error.",
            safety_notes="Please try again later.",
            confidence=0.0,
        )
