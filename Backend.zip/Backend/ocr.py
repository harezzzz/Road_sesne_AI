import easyocr
from PIL import Image

reader = easyocr.Reader(['en'])

def extract_text_from_image(image_path: str) -> str:
    try:
        results = reader.readtext(image_path, detail=0)
        return " ".join(results)
    except Exception as e:
        print(f"OCR Error: {str(e)}")
        return ""
