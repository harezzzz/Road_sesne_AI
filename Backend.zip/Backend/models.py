from pydantic import BaseModel, Field
from typing import List

class RoadMarkingRequest(BaseModel):
    image_filename: str

class RoadMarkingAnalysis(BaseModel):
    detected_labels: List[str] = Field(default_factory=list)
    interpretation: str
    safety_notes: str
    confidence: float
