import os
from pathlib import Path
from pydantic_ai import Agent
from pydantic_ai.providers.openrouter import OpenRouterProvider

from models import RoadMarkingAnalysis

# --------- MANUAL, RELIABLE ENV LOADING (WINDOWS-FRIENDLY) ---------

BASE_DIR = Path(__file__).parent
ENV_PATH = BASE_DIR / ".env"

if not ENV_PATH.exists():
    raise RuntimeError(f".env file not found at: {ENV_PATH}")

# Read the file ourselves
with open(ENV_PATH, "r") as f:
    lines = f.read().strip().splitlines()

env_dict = {}
for line in lines:
    if "=" in line and not line.startswith("#"):
        key, value = line.split("=", 1)
        env_dict[key.strip()] = value.strip()

API_KEY = env_dict.get("OPENROUTER_API_KEY")

if not API_KEY:
    raise RuntimeError(
        f"OPENROUTER_API_KEY not found in {ENV_PATH}. "
        "Make sure the file contains exactly: OPENROUTER_API_KEY=sk-or-v1-..."
    )

# --------- EXPLICIT OPENROUTER PROVIDER ---------
# Ensure the library sees the env var if it relies on os.environ
os.environ["OPENROUTER_API_KEY"] = API_KEY

provider = OpenRouterProvider(api_key=API_KEY)
print("Agent initialized successfully with OpenRouter provider.")

ROAD_AGENT = Agent(
    model="openrouter:meta-llama/llama-3.1-8b-instruct",
    provider=provider,
    result_type=RoadMarkingAnalysis,
    system_prompt="""
    You are an expert in road utility markings and construction safety.
    Your job is to interpret painted road markings related to underground utilities.
    Be clear, structured, and practical.
    Always include a confidence score between 0 and 1.
    """
)

async def analyze_road_marking(image_text: str) -> RoadMarkingAnalysis:
    prompt = f"""
    Based on the following detected text from a road marking image: "{image_text}",
    identify likely utility labels, explain their meaning in simple terms,
    and highlight any safety concerns.
    """

    result = await ROAD_AGENT.run(prompt)
    return result.data
